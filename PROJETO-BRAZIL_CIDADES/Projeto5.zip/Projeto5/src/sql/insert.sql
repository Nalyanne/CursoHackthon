INSERT INTO `Dono` (`DN_NU`, `DN_NO`, `DN_SIT`) VALUES (1, 'Dono 1', 'A');

INSERT INTO `Cachorro` (`CA_NU`, `CA_IDADE`, `CA_NOME`, `DN_NU`) VALUES
(1, 7, 'Cachorro 1', 1),
(2, 8, 'Cachorro 2', 1);
