package com.stefanini.projeto.repository;

import org.springframework.data.repository.CrudRepository;

import com.stefanini.projeto.model.Dono;

public interface DonoRepository extends CrudRepository<Dono, Long>{

}
