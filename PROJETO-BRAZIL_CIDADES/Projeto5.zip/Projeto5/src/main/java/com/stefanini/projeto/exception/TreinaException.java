package com.stefanini.projeto.exception;

public class TreinaException extends Exception {

	private static final long serialVersionUID = 1L;

	public TreinaException(String mensagem) {
		super(mensagem);
	}

}
